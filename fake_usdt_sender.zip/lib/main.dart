
import 'package:flutter/material.dart';

void main() {
  runApp(FakeUsdtSenderApp());
}

class FakeUsdtSenderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fake USDT Sender',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: SenderHomePage(),
    );
  }
}

class SenderHomePage extends StatefulWidget {
  @override
  _SenderHomePageState createState() => _SenderHomePageState();
}

class _SenderHomePageState extends State<SenderHomePage> {
  final _walletController = TextEditingController();
  final _amountController = TextEditingController();
  String _network = 'TRC20';
  bool _bypassFees = false;
  bool _broadcast = false;
  bool _confirmed = false;
  bool _isActivated = false;

  void _showActivationDialog() {
    TextEditingController _codeController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Enter Activation Code'),
        content: TextField(
          controller: _codeController,
          obscureText: true,
          decoration: InputDecoration(hintText: 'Activation Code'),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (_codeController.text == 'A7b9#K2\$mX5!Pq8*') {
                setState(() {
                  _isActivated = true;
                });
                Navigator.pop(context);
                _flashTransaction();
              } else {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text('Invalid activation code'),
                ));
              }
            },
            child: Text('Activate'),
          ),
        ],
      ),
    );
  }

  void _flashTransaction() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Fake USDT sent successfully! TX: 24EEA9...FAkTX'),
      duration: Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Fake USDT Sender')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _walletController,
              decoration: InputDecoration(labelText: 'Wallet Address'),
            ),
            TextField(
              controller: _amountController,
              decoration: InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
            ),
            DropdownButton<String>(
              value: _network,
              onChanged: (value) {
                setState(() {
                  _network = value!;
                });
              },
              items: ['TRC20', 'ERC20', 'BEP20']
                  .map((network) => DropdownMenuItem(
                        value: network,
                        child: Text(network),
                      ))
                  .toList(),
            ),
            SizedBox(height: 20),
            Text('TRANSACTION SETTINGS'),
            CheckboxListTile(
              title: Text('Bypass/Wave Network Fees'),
              value: _bypassFees,
              onChanged: (val) => setState(() => _bypassFees = val!),
            ),
            CheckboxListTile(
              title: Text('Broadcast Transaction to Blockchain'),
              value: _broadcast,
              onChanged: (val) => setState(() => _broadcast = val!),
            ),
            CheckboxListTile(
              title: Text('Make Transaction 100% Confirmed'),
              value: _confirmed,
              onChanged: (val) => setState(() => _confirmed = val!),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isActivated ? _flashTransaction : _showActivationDialog,
              child: Text('FLASH'),
            ),
          ],
        ),
      ),
    );
  }
}
